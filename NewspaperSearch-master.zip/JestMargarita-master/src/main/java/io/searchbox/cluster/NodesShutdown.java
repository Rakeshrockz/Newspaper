package io.searchbox.cluster;

/**
 * @author Dogukan Sonmez
 */


public class NodesShutdown {
}
