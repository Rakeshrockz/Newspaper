package io.searchbox.indices;

/**
 * @author Dogukan Sonmez
 */


public class Aliases {
}
